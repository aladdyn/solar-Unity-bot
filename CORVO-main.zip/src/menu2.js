const menu2 = (prefix) => { 
	return `                 
╠══✪〘 MENU 〙✪══
║
╠➥ *${prefix}figu*
╠➥ *${prefix}toimg*
╠➥ *${prefix}meme*
╠➥ *${prefix}memeindo*
╠➥ *${prefix}tts*
╠➥ *${prefix}loli [off]*
╠➥ *${prefix}nsfwloli [off]*
╠➥ *${prefix}url2img*
╠➥ *${prefix}leens [na legenda]*
╠➥ *${prefix}wait [na legenda]*
╠➥ *${prefix}setprefix*
║
╠══✪〘 IMAGENS 〙✪══
║
╠➸ *${prefix}loli* [off]
╠➸ *${prefix}loli1*
╠➸ *${prefix}hentai*
╠➸ *${prefix}dono*
╠➸ *${prefix}porno*
╠➸ *${prefix}boanoite*
╠➸ *${prefix}bomdia*
╠➸ *${prefix}boatarde*
╠➸ *${prefix}mia*
╠➸ *${prefix}mia1*
╠➸ *${prefix}mia2*
╠➸ *${prefix}belle*
╠➸ *${prefix}belle1*
╠➸ *${prefix}belle2*
╠➸ *${prefix}belle3*
╠➸ *${prefix}akeno*
╠➸ *${prefix}meme*   
╠➸ *${prefix}lofi*
╠➸ *${prefix}malkova*
╠➸ *${prefix}canal*
╠➸ *${prefix}nsfwloli1*
╠➸ *${prefix}reislin*
║
╠══✪〘 INTELIGÊNCIA IA 〙✪══
║
╠➸ *${prefix}simih 1 (para ativar)*
╠➸ *${prefix}simih 0 (para desativar)*
╠➥ *${prefix}simi (sua mensagem)*
║
╠══✪〘 *SOLAR UNITY BOT* 〙✪══`
}
exports.menu2 = menu2